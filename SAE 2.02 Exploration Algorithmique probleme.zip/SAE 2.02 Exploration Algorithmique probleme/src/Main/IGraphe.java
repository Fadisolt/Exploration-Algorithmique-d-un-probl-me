package Main;

public interface IGraphe {

            void ajouterSommet(String nom);

    void ajouterArete(String depart, String etiquette, String arrive);

    boolean existeArete(String depart, String arrive);

    String getEtiquette(String depart, String arrive);

}
